(function($) {
    $('.menu-toggle > a').on('click', function (e) {
        e.preventDefault();
        $('#responsive-nav').toggleClass('active');
        return false;
    });

   

})(jQuery);
